# Ministree Template Spec (v0.4)

How to build a **code-driven website template** that plugs into Ministree like a
WordPress theme. A template is its own Next.js app that reads a church's full site
through the public API, renders its pages/sections/archives with **your own
components**, and lets Ministree inject the church's palette + content.

Deploy it **once for every church** (multi-tenant, §0) or **once per church**
(env-pinned). One build does both.

This is for **bespoke, code-first templates**. Churches edit a code-template through
a **Customizer** (the fields + tokens you declare) — they don't drag-drop blocks.

## The WordPress mapping

| WordPress | Ministree |
| --- | --- |
| `style.css` header / `theme.json` | `ministree.config.ts` manifest |
| `add_theme_support(...)` | `manifest.supports` — surfaces, section types, colour schemes, nav |
| The Loop / template tags | SDK data functions (`getPage`, `getSermons`, `getNavigation`, …) |
| `the_content()` | `<Sections registry={yours}>` + `<RichText>` |
| Customizer | Ministree auto-generates a form from `manifest.content` + `manifest.tokens` |

## 0. Pick a hosting model

**Multi-tenant (recommended).** You deploy once; Ministree tells you which church
each request belongs to, resolved from its `Host`. Churches get a site address in
one click, with no deploy of their own — which is what makes a browsable gallery
mean anything.

```ts
// ministree.config.ts
hosting: { multiTenant: true },
compatibility: { deploymentMode: 'both' },
```

```tsx
// any server component
import { ministree } from '@ministree/template-sdk/next';
const ms = await ministree();           // once per request
const sermons = await getSermons(ms);   // every accessor already takes a client
```

**Env-pinned.** No `ministree()` call; set `NEXT_PUBLIC_ORG_SLUG` and the SDK
resolves from env. This is how a **self-hosted (single-deployment) install** works:
that Ministree lives on its own API origin, and a deploy can only point at one, so
a shared deploy can't serve it.

Env **wins** the resolution order, so a `multiTenant: true` template still runs
env-pinned when a church deploys it themselves. Declare `deploymentMode: 'both'`
unless you genuinely only support one — the gallery filters on it, and `'multi'`
hides you from every self-hosted church.

## 1. Declare a manifest — `ministree.config.ts`

```ts
import { defineMinistreeTemplate } from '@ministree/template-sdk';

export default defineMinistreeTemplate({
  meta: { name: 'Flame', author: 'You', version: '1.0.0' },

  compatibility: { sdk: '^0.2.0', deploymentMode: 'single', requiresModules: [] },

  // DECLARE WHAT YOU SUPPORT — Ministree reads this to know what to link/offer
  // and to warn when a church uses something you can't render.
  supports: {
    surfaces: ['home','page','sermonArchive','sermonDetail','eventArchive','eventDetail',
               'blogArchive','blogDetail','giving','form','search','notFound'],
    sections: ['hero','richText','cta','features','imageGallery','sermonsList','eventsList', /* … */],
    navigation: { header: true, footer: true },
    colorSchemes: ['light','dark'],   // which schemes you render
  },

  // CSS vars you expose. `default` is the light value, `darkDefault` the dark one.
  // `maps` names the church brand colour the picker SUGGESTS for a token — it is
  // not a binding. Your defaults ship; a church opts in to a brand colour.
  tokens: [
    { name: '--accent', default: '#e2562a', darkDefault: '#ff7a45', maps: '--color-primary' },
    { name: '--bg',     default: '#ffffff', darkDefault: '#0c0805' },
  ],

  // Looks you ship. A preset sets several tokens at once — colours, fonts, radii —
  // and a church applies one in a click. Your defaults are always offered beside
  // them as "Original". Tokens only: a preset never reaches content.
  presets: [
    {
      id: 'midnight',
      label: 'Midnight',
      tokens: {
        '--bg': { light: '#0b0f16', dark: '#05080d' },
        '--accent': '#4f8cff',           // same in both schemes
        '--radius': '0.5rem',
      },
    },
  ],

  content: { defaults: { /* your demo content */ }, fields: { /* Customizer schema */ } },
  data: [{ source: 'giving', as: 'give' }],
});
```

`defineMinistreeTemplate` validates at import — a bad manifest fails the build.

## 2. Read the church (data layer)

All return `null` when unconfigured or absent, so you fall back to defaults.

```ts
import { getPage, getSitePages, getNavigation, getSermons, getSermon,
         getEvents, getEvent, getPosts, getPost, getSiteSettings } from '@ministree/template-sdk';
```

Surfaces ↔ loaders: home/pages → `getPage`; sermons → `getSermons`/`getSermon`/`getSermonSeries`/`getSermonSpeakers`; events → `getEvents`/`getEvent`; blog → `getPosts`/`getPost`/`getPostCategories`; giving → `getGiving`; forms → `getForm`.

## 3. Render CMS pages (sections)

CMS pages are arrays of typed sections. You provide a **registry** — your component
per section type — and the SDK dispatches:

```tsx
import { Sections, type SectionRegistry, resolveSectionWrapper } from '@ministree/template-sdk';
import Hero from './sections/Hero';

export const registry: SectionRegistry = { hero: Hero, richText: RichTextSection, /* … */ };

const page = await getPage(slug);
<Sections sections={page?.content?.sections} registry={registry}
          context={{ pageDefaultAlign: page?.content?.defaultSectionTextAlign }} />
```

Each component receives `{ section, props, context }`. Use `resolveSectionWrapper(section, context)`
(or `<SectionWrapper>`) to apply visibility, background, alignment, and the dark flag.
Unregistered/hidden types are skipped (dev-warned). `assertRegistryMatchesSupports(manifest.supports.sections, registry)` keeps the two in sync.

## 4. Routing (honour church slug overrides)

Churches can remap slugs (sermons → `/messages`). Build links from the live map:

```ts
import { getSitePages, resolveSitePageSlugs, hrefFor } from '@ministree/template-sdk';
const slugs = resolveSitePageSlugs(await getSitePages());
hrefFor(slugs, 'sermons');                 // '/messages'
hrefFor(slugs, 'sermons', sermon.slug);    // '/messages/easter-2026'
```

## 4b. Let the church choose the content (`entity`)

An `entity` field lets a church point your template at specific content:

```ts
// in content.fields
featuredEvent: { kind: 'entity', module: 'events', label: 'Which event?' },
speakers:      { kind: 'entity', module: 'people', multiple: true, max: 6 },
```

The church gets a picker; you get the public **slug** (or an array of them),
which is exactly what the accessors take:

```tsx
import { resolveEntities } from '@ministree/template-sdk';
const [event] = await resolveEntities(ms, 'events', content.featuredEvent);
```

`resolveEntities` drops anything that no longer resolves rather than throwing —
a church can unpublish the event your page features, and a hole beats a broken
site. Handle the empty case: fall back to your own default rather than rendering
a blank page.

## 4c. Drawn controls (`choice`)

Ministree draws a set of visual pickers you can name instead of building your
own dropdown:

```ts
focalPoint: { kind: 'choice', control: 'focalPoint', label: 'Focal point' },
```

You receive one of the values listed for that control. Naming one Ministree
doesn't recognise falls back to a plain dropdown built from your `options`, so a
template built against a newer SDK stays usable in an older admin. The full
catalogue is in `docs/field-controls.md`.

## 5. Theme + light/dark

```tsx
import manifest from '../ministree.config';
import { resolveThemeCss, resolveColorScheme, getSiteSettings, getVisibility } from '@ministree/template-sdk';

const settings = await getSiteSettings();
const css = resolveThemeCss(manifest, { siteSettings: settings }); // :root + .dark blocks
const scheme = resolveColorScheme(settings, { visibility: await getVisibility(path) });
// <html className={scheme === 'dark' ? 'dark' : ''}><style dangerouslySetInnerHTML={{__html: css}}/>
```

`resolveThemeCss` emits a `:root` block and (when you declare `colorSchemes: ['light','dark']`)
a `.dark` block; toggling the `.dark` class switches schemes. `resolveColorScheme` honours a
route's `forceDarkTheme`, an explicit user choice, then the church's `darkModeEnabled` + system preference.

## 6. Rich text

```tsx
import { RichText } from '@ministree/template-sdk';
<RichText doc={sermon.content} className="prose" />
```

## 7. Live publish + Customizer preview (v0.3)

Wire two routes (2 lines each) and mount the bridge, and Ministree's Customizer
gets instant colour preview, draft content preview, and publish-in-seconds:

```ts
// app/api/ministree/revalidate/route.ts — Ministree pings this on Publish
import { createRevalidateRoute } from '@ministree/template-sdk/next';
export const { POST } = createRevalidateRoute();

// app/api/ministree/preview/route.ts — the Customizer iframe enters here
import { createPreviewRoute } from '@ministree/template-sdk/next';
export const { GET } = createPreviewRoute();
```

```tsx
// app/layout.tsx (server component)
import { getPreviewToken } from '@ministree/template-sdk/next';
import { PreviewBridge } from '@ministree/template-sdk/preview';
const previewToken = await getPreviewToken();
// in the body: {previewToken ? <PreviewBridge token={previewToken} /> : null}
```

Import `getTemplateContent` from `@ministree/template-sdk/next` (not the main
entry) so preview requests read the church's DRAFT overrides; all other requests
keep the normal cached fetch. Every SDK fetch is tagged `ministree`, so the
revalidate ping refreshes the whole site at once.

Field descriptors accept `visibleWhen: { field, equals }` (or `in: [...]`) to
show a field only when a sibling matches — e.g. a slug input only when a
`select` chooses the CMS-page mode.

Serve `/ministree-manifest` with `export const revalidate = 300` rather than
`force-static` so a "Refresh manifest" in the admin can pick up redeployed
fields without a rebuild.

## 8. Env + validate

```
NEXT_PUBLIC_MINISTREE_API_URL=https://api.ministr.ee   # or NEXT_PUBLIC_API_URL
NEXT_PUBLIC_ORG_SLUG=<church-slug>   # env-pinned only; omit when multi-tenant
NEXT_PUBLIC_MINISTREE_TEMPLATE_ID=<id>   # env-pinned only; multi-tenant reads ms.templateId
```

On a multi-tenant deploy the Customizer's preview link carries `&org=` and
`&template=`, so `createPreviewRoute()` needs no extra wiring.

```
npx ministree-template validate .
```

Reports the manifest + everything it `supports` (surfaces, sections, schemes, nav).
